package com.ubu.ububot.test;

import java.lang.reflect.Method;

import android.test.ActivityInstrumentationTestCase2;
import android.util.Log;

import com.ubu.ububot.controlador.MoveToPointActivity;

public class TestMoveToPoint extends ActivityInstrumentationTestCase2<MoveToPointActivity>{

	Object result;
	
	public TestMoveToPoint() {
		super(MoveToPointActivity.class);
	}

	@Override
	public void setUp() throws Exception {
		super.setUp();
	}

	public void testPassToString(){
		final Method methodPassToString;
		final Method methodPassToString2;
		try {			
			methodPassToString = MoveToPointActivity.class.getDeclaredMethod("passToString", new Class[] {Integer.TYPE});
			methodPassToString.setAccessible(true);
		    
			getActivity().runOnUiThread(new Runnable() {
                public void run(){
                	try {
                		result = methodPassToString.invoke(getActivity(), 123);
					} catch (Exception e) {
						Log.e("TestUbuBot", "Error al invocar el metodo passToString", e);
					}
                }
            });		
			
			Thread.sleep(100);
			
			// Comprobamos que no sea vacia
			assertNotNull("No deberia ser null",result);
			// Comprobamos que sea un string
			assertTrue("Deberia ser un String", result.getClass() == String.class);
			// Comprobamos que es el mismo string
			assertEquals("Deberia devolver 000123", result,"000123");
			
			// Probamos ahora con un valor negativo
			methodPassToString2 = MoveToPointActivity.class.getDeclaredMethod("passToString", new Class[] {Integer.TYPE});
			methodPassToString2.setAccessible(true);
		    
			getActivity().runOnUiThread(new Runnable() {
                public void run(){
                	try {
                		result = methodPassToString2.invoke(getActivity(), -1234);
					} catch (Exception e) {
						Log.e("TestUbuBot", "Error al invocar el metodo passToString", e);
					}
                }
            });		
			
			Thread.sleep(100);
			
			// Comprobamos que no sea vacia
			assertNotNull("No deberia ser null",result);
			// Comprobamos que sea un string
			assertTrue("Deberia ser un String", result.getClass() == String.class);
			// Comprobamos que es el mismo string
			assertEquals("Deberia devolver -01234", result,"-01234");
			
			
		} catch (Exception e) {
			Log.e("TestUbuBot", "Error al invocar el metodo passToString", e);
		}
	}
	
	@Override
	public void tearDown() throws Exception {
		super.tearDown();
	}

}
