package com.ubu.ububot.test;

import java.lang.reflect.Method;

import android.test.ActivityInstrumentationTestCase2;
import android.util.Log;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;

import com.robotium.solo.Solo;
import com.ubu.ububot.R;
import com.ubu.ububot.controlador.MainActivity;

public class TestMainActivity extends ActivityInstrumentationTestCase2<MainActivity> {
	private Solo solo;
	
	// Componentes de la interfaz grafica
	private ImageButton down;
	private ImageButton up;
	private ImageButton right;
	private ImageButton left;
	private TextView lbSpeed;
	private EditText speed;
	private TextView lbPositionX;
	private TextView positionX;
	private TextView lbPositionY;
	private TextView positionY;
	
	// Resultado de invocaciones
	Object result;

	public TestMainActivity() {
		super(MainActivity.class);
	}

	@Override
	protected void setUp() throws Exception {
		super.setUp();
		solo = new Solo(getInstrumentation(), getActivity());
		
		// Obtenemos todos los componentes del layout
		down = (ImageButton) solo.getView(R.id.button_down);
		up = (ImageButton) solo.getView(R.id.button_up);
		right = (ImageButton) solo.getView(R.id.button_right);
		left = (ImageButton) solo.getView(R.id.button_left);
		lbSpeed = (TextView) solo.getView(R.id.lb_speed);
		speed = (EditText) solo.getView(R.id.speed);
		lbPositionX = (TextView) solo.getView(R.id.lb_position_x);
		positionX = (TextView) solo.getView(R.id.position_x);
		lbPositionY = (TextView) solo.getView(R.id.lb_position_y);
		positionY = (TextView) solo.getView(R.id.position_y);
	}
	
	public void testVisibility() {		
		// Hacemos visibles los componente
		// Como el metodo es privado le invocamos por reflexi�n
		final Method methodVisible;
		try {			
			methodVisible = MainActivity.class.getDeclaredMethod("setVisible");
			methodVisible.setAccessible(true);
		    
			getActivity().runOnUiThread(new Runnable() {
                public void run(){
                	try {
                		methodVisible.invoke(getActivity());
					} catch (Exception e) {
						Log.e("TestUbuBot", "Error al invocar el metodo setVisible", e);
					}
                }
            });

		} catch (Exception e) {
			Log.e("TestUbuBot", "Error al invocar el metodo setVisible", e);
		}
		
		//Esperamos un rato para que se ejecute el metodo
		solo.sleep(100);
		
		// Comprobamos que los componentes estan visibles
		assertTrue("Boton avanzar deber�a estar visible", up.isShown());
		assertTrue("Boton retroceder deber�a estar visible", down.isShown());
		assertTrue("Boton derecha deber�a estar visible", right.isShown());
		assertTrue("Boton izquierda deber�a estar visible", left.isShown());
		assertTrue("Etiqueta velocidad deber�a estar visible", lbSpeed.isShown());
		assertTrue("Valor de velocidad deber�a estar visible", speed.isShown());
		assertTrue("Etiqueta posici�n X deber�a estar visible", lbPositionX.isShown());
		assertTrue("Valor de X deber�a estar visible", positionX.isShown());
		assertTrue("Etiqueta posici�n Y deber�a estar visible", lbPositionY.isShown());
		assertTrue("Valor de Y deber�a estar visible",positionY.isShown());
		
		
		//Ahora les volvemos a hacer invisibles
		// Como el metodo es privado le invocamos por reflexi�n
		final Method methodInvisible;
		try {			
			methodInvisible = MainActivity.class.getDeclaredMethod("setInvisible");
			methodInvisible.setAccessible(true);
		    
			getActivity().runOnUiThread(new Runnable() {
                public void run(){
                	try {
                		methodInvisible.invoke(getActivity());
					} catch (Exception e) {
						Log.e("TestUbuBot", "Error al invocar el metodo setInvisible", e);
					}
                }
            });

		} catch (Exception e) {
			Log.e("TestUbuBot", "Error al invocar el metodo setInvisible", e);
		}
		
		//Esperamos un rato para que se ejecute el metodo
		solo.sleep(100);
		
		// Comprobamos que los componentes estan ocultos
		assertFalse("Boton avanzar deber�a estar oculto", up.isShown());
		assertFalse("Boton retroceder deber�a estar oculto", down.isShown());
		assertFalse("Boton derecha deber�a estar oculto", right.isShown());
		assertFalse("Boton izquierda deber�a estar oculto", left.isShown());
		assertFalse("Etiqueta velocidad deber�a estar oculto", lbSpeed.isShown());
		assertFalse("Valor de velocidad deber�a estar oculto", speed.isShown());
		assertFalse("Etiqueta posici�n X deber�a estar oculto", lbPositionX.isShown());
		assertFalse("Valor de X deber�a estar oculto", positionX.isShown());
		assertFalse("Etiqueta posici�n Y deber�a estar oculto", lbPositionY.isShown());
		assertFalse("Valor de Y deber�a estar oculto",positionY.isShown());	
	}
	
	public void testPassToString(){
		final Method methodPassToString;
		try {			
			methodPassToString = MainActivity.class.getDeclaredMethod("passToString", new Class[] {Integer.TYPE});
			methodPassToString.setAccessible(true);
		    
			getActivity().runOnUiThread(new Runnable() {
                public void run(){
                	try {
                		result = methodPassToString.invoke(getActivity(), 23);
					} catch (Exception e) {
						Log.e("TestUbuBot", "Error al invocar el metodo passToString", e);
					}
                }
            });		
			
			
			solo.sleep(100);
			
			// Comprobamos que no sea vacia
			assertNotNull("No deberia ser null",result);
			// Comprobamos que sea un string
			assertTrue("Deberia ser un String", result.getClass() == String.class);
			// Comprobamos que es el mismo string
			assertEquals("Deberia devolver 023", result,"023");
			
		} catch (Exception e) {
			Log.e("TestUbuBot", "Error al invocar el metodo passToString", e);
		}
	}
	
	public void testStatus(){
		final Method methodSetStatus;
		final Method methodSetStatus2;
		final Method methodSetStatus3;
		final Method methodSetStatus4;
		try {			
			methodSetStatus = MainActivity.class.getDeclaredMethod("setStatus", new Class[] {Integer.TYPE});
			methodSetStatus.setAccessible(true);
		    
			getActivity().runOnUiThread(new Runnable() {
                public void run(){
                	try {
                		result = methodSetStatus.invoke(getActivity(), R.string.title_connecting);
					} catch (Exception e) {
						Log.e("TestUbuBot", "Error al invocar el metodo setStatus", e);
					}
                }
            });		
			
			solo.sleep(100);
			
			// Comprobamos que se ha cambiado el texto
			assertTrue("Deberia mostrarse texto conectando",solo.searchText(solo.getString(R.string.title_connecting)));
			
			// Realizamos otra prueba
			methodSetStatus2 = MainActivity.class.getDeclaredMethod("setStatus", new Class[] {Integer.TYPE});
			methodSetStatus2.setAccessible(true);
		    
			getActivity().runOnUiThread(new Runnable() {
                public void run(){
                	try {
                		result = methodSetStatus2.invoke(getActivity(), R.string.title_not_connected);
					} catch (Exception e) {
						Log.e("TestUbuBot", "Error al invocar el metodo setStatus", e);
					}
                }
            });		
			
			solo.sleep(100);
			
			// Comprobamos que se ha cambiado el texto
			assertTrue("Deberia mostrarse texto no conectado",solo.searchText(solo.getString(R.string.title_not_connected)));
			
			methodSetStatus3 = MainActivity.class.getDeclaredMethod("setStatus", new Class[] {CharSequence.class});
			methodSetStatus3.setAccessible(true);
		    
			getActivity().runOnUiThread(new Runnable() {
                public void run(){
                	try {
                		result = methodSetStatus3.invoke(getActivity(), "Prueba setStatus");
					} catch (Exception e) {
						Log.e("TestUbuBot", "Error al invocar el metodo setStatus", e);
					}
                }
            });		
			
			solo.sleep(100);
			
			// Comprobamos que se ha cambiado el texto
			assertTrue("Deberia mostrarse texto Prueba setStatus",solo.searchText("Prueba setStatus"));
			
			// Realizamos otra prueba
			methodSetStatus4 = MainActivity.class.getDeclaredMethod("setStatus", new Class[] {CharSequence.class});
			methodSetStatus4.setAccessible(true);
		    
			getActivity().runOnUiThread(new Runnable() {
                public void run(){
                	try {
                		result = methodSetStatus4.invoke(getActivity(), "Conectado a UBUBOT");
					} catch (Exception e) {
						Log.e("TestUbuBot", "Error al invocar el metodo setStatus", e);
					}
                }
            });		
			
			solo.sleep(100);
			
			// Comprobamos que se ha cambiado el texto
			assertTrue("Deberia mostrarse texto Conectado a UBUBOT",solo.searchText("Conectado a UBUBOT"));
			
		} catch (Exception e) {
			Log.e("TestUbuBot", "Error al invocar el metodo setStatus", e);
		}
	}
	
	@Override
	protected void tearDown() throws Exception {
		solo.finishOpenedActivities();
		super.tearDown();
	}

}
