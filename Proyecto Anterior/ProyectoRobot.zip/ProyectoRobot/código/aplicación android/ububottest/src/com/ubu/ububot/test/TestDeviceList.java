package com.ubu.ububot.test;

import java.lang.reflect.Method;

import android.test.ActivityInstrumentationTestCase2;
import android.util.Log;

import com.robotium.solo.Solo;
import com.ubu.ububot.R;
import com.ubu.ububot.controlador.DeviceListActivity;

public class TestDeviceList extends ActivityInstrumentationTestCase2<DeviceListActivity>{
	private Solo solo;	
	
	public TestDeviceList() {
		super(DeviceListActivity.class);
	}

	@Override
	public void setUp() throws Exception {
		super.setUp();
		solo = new Solo(getInstrumentation(), getActivity());
	}

	public void testDoDiscovery(){
		final Method methodDoDiscovery;
		try {			
			methodDoDiscovery = DeviceListActivity.class.getDeclaredMethod("doDiscovery");
			methodDoDiscovery.setAccessible(true);
		    
			getActivity().runOnUiThread(new Runnable() {
                public void run(){
                	try {
                		methodDoDiscovery.invoke(getActivity());
					} catch (Exception e) {
						Log.e("TestUbuBot", "Error al invocar el metodo doDiscovery", e);
					}
                }
            });		
			
			solo.sleep(100);
			
			// Comprobamos que se mueste el texto de escaneando dispositivos
			assertEquals("Deberia mostrarse texto Escanenado", solo.getCurrentActivity().getTitle(),solo.getString(R.string.scanning));	
		} catch (Exception e) {
			Log.e("TestUbuBot", "Error al invocar el metodo doDiscovery", e);
		}
	}
	
	@Override
	public void tearDown() throws Exception {
		super.tearDown();
	}

}
