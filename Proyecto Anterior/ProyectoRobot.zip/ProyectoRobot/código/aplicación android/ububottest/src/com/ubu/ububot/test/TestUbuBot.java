package com.ubu.ububot.test;

import com.robotium.solo.Solo;
import com.ubu.ububot.controlador.MainActivity;
import com.ubu.ububot.controlador.MoveToPointActivity;
import com.ubu.ububot.R;

import android.test.ActivityInstrumentationTestCase2;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;

public class TestUbuBot extends ActivityInstrumentationTestCase2<MainActivity> {
	private Solo solo;
	private boolean conectado = false;
	
	// Componentes de la interfaz grafica
	private ImageButton down;
	private ImageButton up;
	private ImageButton right;
	private ImageButton left;
	private TextView lbSpeed;
	private EditText speed;
	private TextView lbPositionX;
	private TextView positionX;
	private TextView lbPositionY;
	private TextView positionY;
	private EditText valX;
	private EditText valY;
	private Button moveTo;
	
	public TestUbuBot() {
		super(MainActivity.class);
	}

	@Override
	protected void setUp() throws Exception {
		super.setUp();
		solo = new Solo(getInstrumentation(), getActivity());
		
		// Obtenemos todos los componentes del layout
		down = (ImageButton) solo.getView(R.id.button_down);
		up = (ImageButton) solo.getView(R.id.button_up);
		right = (ImageButton) solo.getView(R.id.button_right);
		left = (ImageButton) solo.getView(R.id.button_left);
		lbSpeed = (TextView) solo.getView(R.id.lb_speed);
		speed = (EditText) solo.getView(R.id.speed);
		lbPositionX = (TextView) solo.getView(R.id.lb_position_x);
		positionX = (TextView) solo.getView(R.id.position_x);
		lbPositionY = (TextView) solo.getView(R.id.lb_position_y);
		positionY = (TextView) solo.getView(R.id.position_y);
		
	}
	
	public void testUbuBot(){
		
		// Comprobamos que los componentes estan ocultos
		assertFalse("Boton avanzar deber�a estar oculto", up.isShown());
		assertFalse("Boton retroceder deber�a estar oculto", down.isShown());
		assertFalse("Boton derecha deber�a estar oculto", right.isShown());
		assertFalse("Boton izquierda deber�a estar oculto", left.isShown());
		assertFalse("Etiqueta velocidad deber�a estar oculto", lbSpeed.isShown());
		assertFalse("Valor de velocidad deber�a estar oculto", speed.isShown());
		assertFalse("Etiqueta posici�n X deber�a estar oculto", lbPositionX.isShown());
		assertFalse("Valor de X deber�a estar oculto", positionX.isShown());
		assertFalse("Etiqueta posici�n Y deber�a estar oculto", lbPositionY.isShown());
		assertFalse("Valor de Y deber�a estar oculto",positionY.isShown());	
			
		solo.clickOnActionBarItem(R.id.connect);
		
		ListView pairedListView = (ListView) solo.getView(R.id.paired_devices);
		
		if(solo.searchText("UBUBOT")){
			for(int i=0;i < pairedListView.getCount();i++){
				TextView dispositivo = (TextView) pairedListView.getChildAt(i);
				if(dispositivo.getText().toString().indexOf("UBUBOT") >= 0){
					solo.clickOnView(dispositivo);
					conectado = true;
					// Esperamos para que conecte
					solo.sleep(3000);
				}
			}			
		} else {
			Button scanButton = (Button) solo.getView(R.id.button_scan);
			ListView newDevicesListView = (ListView) solo.getView(R.id.new_devices);
			
			solo.clickOnView(scanButton);
			// Esperamos para que busque dispositivos
			solo.sleep(5000);
			
			int i;
			for(i=0;i < newDevicesListView.getCount();i++){
				TextView dispositivo = (TextView) newDevicesListView.getChildAt(i);
				if(dispositivo.getText().toString().indexOf("UBUBOT") >= 0){
					Log.i("TestUbuBot", "Descubierto UBUBOT, vincule manualmente y vuelva a ejecutar los tests.");
					break;
				}
			}
			
			if (i == newDevicesListView.getCount()){
				Log.i("TestUbuBot", "No se descubrio UBUBOT, por favor situese cerca de �l, y vuelva a ejecutar los tests.");
			}
		}
		
		if(conectado == true){
			String valueX, valueY;
			
			// Comprobamos que los componentes estan ocultos
			assertTrue("Boton avanzar deber�a estar oculto", up.isShown());
			assertTrue("Boton retroceder deber�a estar oculto", down.isShown());
			assertTrue("Boton derecha deber�a estar oculto", right.isShown());
			assertTrue("Boton izquierda deber�a estar oculto", left.isShown());
			assertTrue("Etiqueta velocidad deber�a estar oculto", lbSpeed.isShown());
			assertTrue("Valor de velocidad deber�a estar oculto", speed.isShown());
			assertTrue("Etiqueta posici�n X deber�a estar oculto", lbPositionX.isShown());
			assertTrue("Valor de X deber�a estar oculto", positionX.isShown());
			assertTrue("Etiqueta posici�n Y deber�a estar oculto", lbPositionY.isShown());
			assertTrue("Valor de Y deber�a estar oculto",positionY.isShown());	
			
			// Obtenemos valores de X e Y
			valueX = positionX.getText().toString();
			valueY = positionY.getText().toString();
			
			// Establecemos velocidad 0
			solo.clearEditText(speed);
			solo.enterText(speed, "0");
			
			// Pulsamos los botones y comprobamos que las coordenadas no hayan cambiado
			solo.clickLongOnView(up, 500);
			assertTrue("Las coordenadas no deberian haber cambiado", valueX.equals(positionX.getText().toString()) && valueY.equals(positionY.getText().toString()));
			solo.clickLongOnView(down, 500);
			assertTrue("Las coordenadas no deberian haber cambiado", valueX.equals(positionX.getText().toString()) && valueY.equals(positionY.getText().toString()));
			solo.clickLongOnView(left, 500);
			assertTrue("Las coordenadas no deberian haber cambiado", valueX.equals(positionX.getText().toString()) && valueY.equals(positionY.getText().toString()));
			solo.clickLongOnView(right, 500);
			assertTrue("Las coordenadas no deberian haber cambiado", valueX.equals(positionX.getText().toString()) && valueY.equals(positionY.getText().toString()));
			
			// Establecemos velocidad 100
			solo.clearEditText(speed);
			solo.enterText(speed, "100");
						
			// Pulsamos los botones y comprbamos que las coordenadas hayan cambiado
			solo.clickLongOnView(up, 800);
			assertFalse("Las coordenadas deberian haber cambiado", valueX.equals(positionX.getText().toString()) && valueY.equals(positionY.getText().toString()));
			valueX = positionX.getText().toString();
			valueY = positionY.getText().toString();
			solo.clickLongOnView(down, 800);
			assertFalse("Las coordenadas deberian haber cambiado", valueX.equals(positionX.getText().toString()) && valueY.equals(positionY.getText().toString()));
			valueX = positionX.getText().toString();
			valueY = positionY.getText().toString();
			solo.clickLongOnView(left, 800);
			assertFalse("Las coordenadas deberian haber cambiado", valueX.equals(positionX.getText().toString()) && valueY.equals(positionY.getText().toString()));
			valueX = positionX.getText().toString();
			valueY = positionY.getText().toString();
			solo.clickLongOnView(right, 800);
			assertFalse("Las coordenadas deberian haber cambiado", valueX.equals(positionX.getText().toString()) && valueY.equals(positionY.getText().toString()));
			
			// Esperamos un tiempo para que se actualizane los valores de coordenadas
			solo.sleep(500);
			
			// Obtenemos valores de X e Y
			valueX = positionX.getText().toString();
			valueY = positionY.getText().toString();
			
			// Establecemos velocidad 200, valor no valido
			solo.clearEditText(speed);
			solo.enterText(speed, "200");
			
			// Pulsamos los botones y comprobamos que las coordenadas no hayan cambiado
			solo.clickLongOnView(up, 500);
			assertTrue("Las coordenadas no deberian haber cambiado", valueX.equals(positionX.getText().toString()) && valueY.equals(positionY.getText().toString()));
			solo.clickLongOnView(down, 500);
			assertTrue("Las coordenadas no deberian haber cambiado", valueX.equals(positionX.getText().toString()) && valueY.equals(positionY.getText().toString()));
			solo.clickLongOnView(left, 500);
			assertTrue("Las coordenadas no deberian haber cambiado", valueX.equals(positionX.getText().toString()) && valueY.equals(positionY.getText().toString()));
			solo.clickLongOnView(right, 500);
			assertTrue("Las coordenadas no deberian haber cambiado", valueX.equals(positionX.getText().toString()) && valueY.equals(positionY.getText().toString()));
			
			// Establecemos velocidad ububot, valor no valido
			solo.clearEditText(speed);
			solo.enterText(speed, "ububot");
			
			// Pulsamos los botones y comprobamos que las coordenadas no hayan cambiado
			solo.clickLongOnView(up, 500);
			assertTrue("Las coordenadas no deberian haber cambiado", valueX.equals(positionX.getText().toString()) && valueY.equals(positionY.getText().toString()));
			solo.clickLongOnView(down, 500);
			assertTrue("Las coordenadas no deberian haber cambiado", valueX.equals(positionX.getText().toString()) && valueY.equals(positionY.getText().toString()));
			solo.clickLongOnView(left, 500);
			assertTrue("Las coordenadas no deberian haber cambiado", valueX.equals(positionX.getText().toString()) && valueY.equals(positionY.getText().toString()));
			solo.clickLongOnView(right, 500);
			assertTrue("Las coordenadas no deberian haber cambiado", valueX.equals(positionX.getText().toString()) && valueY.equals(positionY.getText().toString()));
			
			
			
			// Probamos la opcion de mover a punto
			solo.clickOnActionBarItem(R.id.moveTo);
			
			// Obtenemos los componentes para actuar con ellos
			valX = (EditText) solo.getView(R.id.x_val);
			valY = (EditText) solo.getView(R.id.y_val);
			moveTo = (Button)solo.getView(R.id.button_move_to_point);
			
			// Comprobamos que sin introducir valores no hace nada
			solo.assertCurrentActivity("No se deberia haber cerrado la pantalla de mover a punto", MoveToPointActivity.class);
			
			// Introducimos valores no valido y comprobamos que hace nada
			solo.clearEditText(valX);
			solo.clearEditText(valY);
			solo.enterText(valX, "120000");
			solo.enterText(valY, "0");
			solo.clickOnView(moveTo);
			solo.assertCurrentActivity("No se deberia haber cerrado la pantalla de mover a punto", MoveToPointActivity.class);
			solo.clearEditText(valX);
			solo.clearEditText(valY);
			solo.enterText(valX, "0");
			solo.enterText(valY, "-600000");
			solo.clickOnView(moveTo);
			solo.assertCurrentActivity("No se deberia haber cerrado la pantalla de mover a punto", MoveToPointActivity.class);
			solo.clearEditText(valX);
			solo.clearEditText(valY);
			solo.enterText(valX, "0");
			solo.enterText(valY, "ububot");
			solo.clickOnView(moveTo);
			solo.assertCurrentActivity("No se deberia haber cerrado la pantalla de mover a punto", MoveToPointActivity.class);
			solo.clearEditText(valX);
			solo.clearEditText(valY);
			solo.enterText(valX, "ububot");
			solo.enterText(valY, "0");
			solo.clickOnView(moveTo);
			solo.assertCurrentActivity("No se deberia haber cerrado la pantalla de mover a punto", MoveToPointActivity.class);
			
			// Damos valores correctos y comprobamos que acaba en las coordenadas indicadas
			solo.clearEditText(valX);
			solo.clearEditText(valY);
			//Obtenemos coordenadas del punto y a�adiremos 1000 a cada valor
			valueX = "" + (Integer.parseInt(positionX.getText().toString())+ 1000);
			valueY = "" + (Integer.parseInt(positionY.getText().toString())+ 1000);
			solo.enterText(valX, valueX);
			solo.enterText(valY, valueY);
			solo.clickOnView(moveTo);
			solo.assertCurrentActivity("Deberia haberse dirigido a la pantalla principal", MainActivity.class);
			
			// Esperamos un tiempo para que el robot llegue a la posicion
			solo.sleep(10000);
			
			// Comprobamos las coordenadas
			assertTrue("La coordenada X no es la correcta", Integer.parseInt(positionX.getText().toString()) > (Integer.parseInt(valueX) - 50) && 
					Integer.parseInt(positionX.getText().toString()) < (Integer.parseInt(valueX) + 50));
			assertTrue("La coordenada Y no es la correcta", Integer.parseInt(positionY.getText().toString()) > (Integer.parseInt(valueY) - 50) && 
					Integer.parseInt(positionY.getText().toString()) < (Integer.parseInt(valueY) + 50));
		}
		
		
		Log.i("TestUbuBot", "Test completado con exito.");
	}	
	
	@Override
	protected void tearDown() throws Exception{
		solo.finishOpenedActivities();
		super.tearDown();
	}
}
