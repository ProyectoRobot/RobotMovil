/** Automatically generated file. DO NOT MODIFY */
package com.ubu.ububot;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}