package com.ubu.ububot.controlador;

import com.ubu.ububot.R;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

/**
 * Actividad para indicar el punto al que se quiere dirigir el robot.
 * @author     Jonatan Santos Barrios
 * @version   1.0
 */
public class MoveToPointActivity extends Activity {
	// Debugging
    private static final String TAG = "MoveToPointActivity";
    private static final boolean D = true;
    
    // Punto como extra del Intent
    public static String EXTRA_POINT = "point";
    
    /**
     * onCreate.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Establecemos la venta y el layaout
        requestWindowFeature(Window.FEATURE_INDETERMINATE_PROGRESS);
        setContentView(R.layout.move_to);
        
        // Ponemos el resultado CANCELED en caso de que el usuario vuelva hacia atras
        setResult(Activity.RESULT_CANCELED);

        // Inicializamos el boton de mover a punto
        Button moveButton = (Button) findViewById(R.id.button_move_to_point);
        moveButton.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
            	moveToPoint();
            }
        });        
    }
    
    /**
     * Funci�n que crea el mensaje a enviar al robot con las coordenadas introducidas por el usuario.
     */
    private void moveToPoint(){
    	if (D) Log.d(TAG, "moveToPoint()");
    	
    	int valueX,valueY;
    	
    	// Obtenemos los Views de las coordenadas
    	EditText valX = (EditText) findViewById(R.id.x_val);
        EditText valY = (EditText) findViewById(R.id.y_val);
        
    	String point = null;
    	
    	try {	
     		//Obtenemos los valores
	    	valueX = Integer.parseInt(valX.getText().toString());
	    	valueY = Integer.parseInt(valY.getText().toString());
	    } catch (Exception e) {
	    	Toast.makeText(this, R.string.no_values, Toast.LENGTH_SHORT).show();
	    	return;
	    }
    	
    	//Comprobamos que los valores introducidos esten dentro de un rango de 100 metros
    	if(valueX > 100000 || valueX < -100000 || valueY > 100000 || valueY < -100000){
    		Toast.makeText(this, R.string.incorrect_values, Toast.LENGTH_SHORT).show();
    	} else {
    		point = "X" +  passToString(valueX) + "Y" + passToString(valueY); 	
        	
	    	// Creamos el intent resultado y a�adimos el punto
	        Intent intent = new Intent();
	        intent.putExtra(EXTRA_POINT, point);
	
	        // Establecemos resultado a OK y finalizamos
	        setResult(Activity.RESULT_OK, intent);
	        finish();
	    }
    }
    
	/**
	 * Funci�n que pasa el valor de la coordenada que es un integer a un formato String de 6 caracteres.
	 * @param value Integer del valor a transformar.
	 * @return string con la transformaci�n.
	 */ 
    private String passToString(int value){
    	String valueString = "";
    	
    	if(value<0){
    		valueString = "-";
    	} else {
    		valueString = "0";
    	}
    	valueString += Integer.toString(Math.abs(value%100000)/10000);
    	valueString += Integer.toString(Math.abs(value%10000)/1000);
    	valueString += Integer.toString(Math.abs(value%1000)/100);
    	valueString += Integer.toString(Math.abs(value%100)/10);
    	valueString += Integer.toString(Math.abs(value%10));
    	
    	return valueString;
    }

}
