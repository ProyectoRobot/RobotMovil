package com.ubu.ububot.controlador;

import com.ubu.ububot.R;
import com.ubu.ububot.modelo.BluetoothService;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.Intent;
import android.support.v4.view.MotionEventCompat;
import android.support.v7.app.ActionBar;
import android.support.v7.app.ActionBarActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Actividad principal, desde la que se podra controlar el robot.
 * @author     Jonatan Santos Barrios
 * @version   1.0
 * @see ActionBarActivity
 */
public class MainActivity extends ActionBarActivity {

	// Debugging
    private static final String TAG = "UbuBot";
    private static final boolean D = true;
    
    // Codigos de solicitud de Intent
    private static final int REQUEST_CONNECT_DEVICE = 1;
    private static final int REQUEST_ENABLE_BT = 2;
    private static final int REQUEST_POINT = 3;
    
    // Tipos de mensajes enviados desde el Handler de BluetoothService
    public static final int MESSAGE_STATE_CHANGE = 1;
    public static final int MESSAGE_READ = 2;
    public static final int MESSAGE_DEVICE_NAME = 3;
    public static final int MESSAGE_TOAST = 4;
    
    // Codigos para movimientos
    public static final int MOVE_STOP = 1;
    public static final int MOVE_DOWN = 2;
    public static final int MOVE_UP = 3;
    public static final int MOVE_LEFT = 4;
    public static final int MOVE_RIGHT = 5;
    
    // Nombres de claves recibidas desde el Handler de BluetoothService
    public static final String DEVICE_NAME = "device_name";
    public static final String TOAST = "toast";   
    
    /**
     * Action Bar.
     */
	private ActionBar actionBar;
    /**
     * Adaptador Bluetooth.
     */
    private BluetoothAdapter mBluetoothAdapter = null;
    /**
     *  Servicio de Bluettoth.
     */
    private BluetoothService mService = null;
    /**
     * Nombre del dispositivo conectado.
     */
    private String mConnectedDeviceName = null;
    
    /**
     * Indicador de coordenada
     */
    private boolean saveInX = true;
    /**
     * Valores de coordenadas
     */
    private String valueX = "", valueY = "";
	
	/**
	 * onCreate.
	 */
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		if(D) Log.e(TAG, "+++ ON CREATE +++");

		// Establecemos el layout
		setContentView(R.layout.main);
		
		 // Obtenemos el adaptador Bluetooth
        mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();

        // Si el adaptador es null, entonces no hay soporte de Bluetooth
        if (mBluetoothAdapter == null) {
            Toast.makeText(this, R.string.not_bluetooth, Toast.LENGTH_LONG).show();
            finish();
            return;
        }
		
        //Obtenemos el ActionBar
		actionBar = getSupportActionBar();
		
		//Obtenemos los botones
		ImageButton btnArriba = (ImageButton) findViewById(R.id.button_up); 
		ImageButton btnAbajo = (ImageButton) findViewById(R.id.button_down); 
		ImageButton btnIzquierda = (ImageButton) findViewById(R.id.button_left); 
		ImageButton btnDerecha = (ImageButton) findViewById(R.id.button_right); 
		
		// Creamos un listener para saber cuando se pulsan y sueltan los botones
		View.OnTouchListener mOnTouchListener = new View.OnTouchListener() {
			
			@Override
			public boolean onTouch(View v, MotionEvent event) {
				
	        	// Obtenemos el tipo de acci�n
				int action = MotionEventCompat.getActionMasked(event);
				 
				// Actuamos seg�n el tipo de acci�n
                switch (action) {
                // Presionar boton
                case (MotionEvent.ACTION_DOWN):
                    // Comprobamos cual de los botones se ha pulsado y llamamos a mover()
                	switch (v.getId()){
                    case (R.id.button_down):
                    	move(MOVE_DOWN);
                    	break;
                    case (R.id.button_up):
                    	move(MOVE_UP);
                		break;
                    case (R.id.button_left):
                    	move(MOVE_LEFT);
                    	break;
                    case (R.id.button_right):
                    	move(MOVE_RIGHT);
                		break;
                    }
                    break;
                // Soltar boton
                case (MotionEvent.ACTION_UP):
                    move(MOVE_STOP);
                    break;
                case (MotionEvent.ACTION_MOVE) :
                	break;
                // Por defecto mandamos parar por seguridad
                case (MotionEvent.ACTION_CANCEL):
                	move(MOVE_STOP);
                	break;
                case (MotionEvent.ACTION_OUTSIDE):
                	move(MOVE_STOP);
                	break;
                }
                return true;
			}
		};
		
		// Asociamos el listener a los botones
		btnArriba.setOnTouchListener(mOnTouchListener);
		btnAbajo.setOnTouchListener(mOnTouchListener);
		btnIzquierda.setOnTouchListener(mOnTouchListener);
		btnDerecha.setOnTouchListener(mOnTouchListener);
		
		setInvisible();
	}

	/**
	 * onStart.
	 */
	@Override
    public void onStart() {
        super.onStart();
        if(D) Log.e(TAG, "++ ON START ++");

        // Si el Bluetooth no est� activo, requiere su activaci�n.
        // start() sera llamado en onActivityResult
        if (!mBluetoothAdapter.isEnabled()) {
            Intent enableIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivityForResult(enableIntent, REQUEST_ENABLE_BT);
        // En otro caso, iniciamos
        } else {
        	if (mService == null) startBluetoothService();
        }
    }
	
	/**
	 * onResume.
	 */
	@Override
    public synchronized void onResume() {
        super.onResume();
        if(D) Log.e(TAG, "+ ON RESUME +");
    }
	
	/**
	 * Funci�n que hace invisibles los componentes de la interfaz gr�fica.
	 */ 
	private void setInvisible(){
		// Hacemos invisibles todos los elementos de la interfa grafica
		findViewById(R.id.button_down).setVisibility(View.INVISIBLE);
		findViewById(R.id.button_left).setVisibility(View.INVISIBLE);
		findViewById(R.id.button_right).setVisibility(View.INVISIBLE);
		findViewById(R.id.button_up).setVisibility(View.INVISIBLE);
		findViewById(R.id.speed).setVisibility(View.INVISIBLE);
		findViewById(R.id.lb_speed).setVisibility(View.INVISIBLE);
		findViewById(R.id.lb_position_x).setVisibility(View.INVISIBLE);
		findViewById(R.id.position_x).setVisibility(View.INVISIBLE);
		findViewById(R.id.lb_position_y).setVisibility(View.INVISIBLE);
		findViewById(R.id.position_y).setVisibility(View.INVISIBLE);
	}
	
	/**
	 * Funci�n que hace visibles los componentes de la interfaz gr�fica.
	 */ 
	private void setVisible(){
		// Hacemos visibles todos los elementos de la interfa gr�fica
		findViewById(R.id.button_down).setVisibility(View.VISIBLE);
		findViewById(R.id.button_left).setVisibility(View.VISIBLE);
		findViewById(R.id.button_right).setVisibility(View.VISIBLE);
		findViewById(R.id.button_up).setVisibility(View.VISIBLE);
		findViewById(R.id.speed).setVisibility(View.VISIBLE);
		findViewById(R.id.lb_speed).setVisibility(View.VISIBLE);
		findViewById(R.id.lb_position_x).setVisibility(View.VISIBLE);
		findViewById(R.id.position_x).setVisibility(View.VISIBLE);
		findViewById(R.id.lb_position_y).setVisibility(View.VISIBLE);
		findViewById(R.id.position_y).setVisibility(View.VISIBLE);
	}
	
	/**
	 * Funci�n que pasa el valor de un integer a un formato String de 3 caracteres.
	 * @param value Integer del valor a transformar.
	 * @return string con la transformaci�n.
	 */ 
    private String passToString(int value){
    	String valueString = "";
    	
    	valueString += Integer.toString(Math.abs(value%1000)/100);
    	valueString += Integer.toString(Math.abs(value%100)/10);
    	valueString += Integer.toString(Math.abs(value%10));
    	
    	return valueString;
    }
	
	/**
	 * Inicia el servicio Bluetooth.
	 */ 
	private void startBluetoothService() {
        // Inicializamos el BluetoothService para poder realizar las conexiones de bluetooth.
        mService = new BluetoothService(this, mHandler);
    }
	
	/**
	 * onResume.
	 */ 
	 @Override
    public synchronized void onPause() {
        super.onPause();
        if(D) Log.e(TAG, "- ON PAUSE -");
    }

	/**
	 * onStop.
	 */ 
    @Override
    public void onStop() {
    	// Mandamos parar al robot
    	move(MOVE_STOP);
        super.onStop();
        if(D) Log.e(TAG, "-- ON STOP --");
    }

	/**
	 * onDestroy.
	 */ 
    @Override
    public void onDestroy() {
        super.onDestroy();
        // Paramos el servicio Bluetooth
        if (mService != null) mService.stop();
        if(D) Log.e(TAG, "--- ON DESTROY ---");
    }

	/**
	 * Funci�n que elabora el mensaje de movimiento a enviar al robot en funci�n del tipo de movimiento pasado.
	 * @param movement Integer que indica el tipo de movimiento a realizar.
	 */ 
    private void move(int movement){
    	String message;
    	int speed;
    	
    	// Obtenemos el View de la velocidad
    	EditText speedText = (EditText) findViewById(R.id.speed);
     	
     	try{
     		//Obtenemos el valor de la velocidad
     		speed = Integer.parseInt(speedText.getText().toString());
     	} catch(Exception e) {
     		Toast.makeText(this, R.string.no_speed, Toast.LENGTH_SHORT).show();
     		return;
     	}
     	
     	//Comprobamos que el valor introducido est� dentro de un rango entre 0 y 127
     	if(speed > 127 || speed < 0){
     		Toast.makeText(this, R.string.incorrect_speed, Toast.LENGTH_SHORT).show();
     		return;
     	}
     	
     	// Seg�n el tipo de movimiento creamos el mensaje
    	switch (movement){
        case (MOVE_DOWN):
        	message = "M-" + passToString(speed) + ",0000";
        	break;
        case (MOVE_UP):
        	message = "M0" + passToString(speed) + ",0000";
    		break;
        case (MOVE_RIGHT):
        	message = "M0000,0" + passToString(speed);
        	break;
        case (MOVE_LEFT):
        	message = "M0000,-" + passToString(speed);
    		break;
    	default:
    		message = "M0000,0000";
    		break;
    	}
    	
    	// Obtenemos la cadena de bytes a enviar
    	byte[] send = message.getBytes();
    	
        // Enviamos el mensaje
    	mService.write(send);
    }
    
	/**
	 * Funci�n que cambia el subtitulo del Action Bar en funci�n del valor pasado.
	 * @param resId Identificador del string que se debe mostrar en el subtitulo.
	 */ 
    private final void setStatus(int resId) {
        actionBar.setSubtitle(resId);
    }

	/**
	 * Funci�n que cambia el subtitulo del Action Bar.
	 * @param subTitle Secuencia de caracteres que se debe mostrar en el subtitulo.
	 */ 
    private final void setStatus(CharSequence subTitle) {
        actionBar.setSubtitle(subTitle);
    }
    
    /**
     *  Handler que recibe la informaci�n de BluetoothService
     */
    private final Handler mHandler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
            // Cambio de estado
            case MESSAGE_STATE_CHANGE:
                if(D) Log.i(TAG, "MESSAGE_STATE_CHANGE: " + msg.arg1);
                switch (msg.arg1) {
                case BluetoothService.STATE_CONNECTED:
                	setVisible();
                    setStatus(getString(R.string.title_connected_to, mConnectedDeviceName));
                    break;
                case BluetoothService.STATE_CONNECTING:
                	setInvisible();
                    setStatus(R.string.title_connecting);
                    break;
                case BluetoothService.STATE_NONE:
                	setInvisible();
                    setStatus(R.string.title_not_connected);
                    break;
                }
                break;
            // Recibe un mensaje
            case MESSAGE_READ:
            	// Obtenemos la cadena de bytes recibidos
            	byte[] readBuf = (byte[]) msg.obj;
                // Pasamos a string
                String readMessage = new String(readBuf, 0, msg.arg1);
                // Analizamos el mensaje para obtener las coordenadas
                for(int i = 0; i < readMessage.length(); i++){
                	String readChar = readMessage.substring(i, i+1);                	
	                if (readChar.equals("X")){
	                	saveInX = true;
	                	valueX = ""; valueY = "";
	                } else if (readChar.equals("Y")){
	                	saveInX = false;
	                }
	                if (saveInX == true){
	                	if (!readChar.equals("X")){
	                		valueX = valueX + readChar;
	                	}
	                } else {
	                	if (!readChar.equals("Y")){
	                		valueY = valueY + readChar;
	                	}
	                }
	                if (valueX.length() == 6 && valueY.length() == 6){
	                	try{
	                		// Escribimos las coordenadas
			                TextView coordenadaX = (TextView) findViewById(R.id.position_x);
			                coordenadaX.setText("" + Integer.parseInt(valueX));
			                TextView coordenadaY = (TextView) findViewById(R.id.position_y);
			                coordenadaY.setText("" + Integer.parseInt(valueY));
	                	} catch (Exception e){
	                		Log.e(TAG, "Error en lectura de coordenadas X: " + valueX + ", Y: " + valueY , e); 
	                		TextView coordenadaX = (TextView) findViewById(R.id.position_x);
			                coordenadaX.setText("Err");
			                TextView coordenadaY = (TextView) findViewById(R.id.position_y);
			                coordenadaY.setText("Err");
	                	}
	                }
            	}
                break;
            // Nombre del dispositivo conectado
            case MESSAGE_DEVICE_NAME:
                // Guardamos el nombre del dispositivo con el que estamos conectados
                mConnectedDeviceName = msg.getData().getString(DEVICE_NAME);
                Toast.makeText(getApplicationContext(), getString(R.string.connected_to) + " " + mConnectedDeviceName, Toast.LENGTH_SHORT).show();
                break;
            // Mensaje a mostrar al usuario
            case MESSAGE_TOAST:
                Toast.makeText(getApplicationContext(), getString((int) msg.getData().getLong(TOAST)), Toast.LENGTH_SHORT).show();
                break;
            }
        }
    };
    
    /**
     * onActivityResult.
     */
    @Override
	public void onActivityResult(int requestCode, int resultCode, Intent data) {
        switch (requestCode) {
        case REQUEST_CONNECT_DEVICE:
        	// Cuando DeviceListActivity nos retorna un dispositivo para conectarnos
            if (resultCode == Activity.RESULT_OK) {
                connectDevice(data);
            }
            break;
        case REQUEST_ENABLE_BT:
            // Cuando se ha permitido habilitar el Bluetooth
            if (resultCode == Activity.RESULT_OK) {
                // Bluetooth habilitado, iniciamos
                startBluetoothService();
            } else {
                // Usuario no ha habilitado el Bluetooth
                Toast.makeText(this, R.string.bt_not_enable, Toast.LENGTH_SHORT).show();
                finish();
            }
            break;
        case REQUEST_POINT:
        	// Cuando MoveToPointActivity nos retorna el punto al que moverse
        	if (resultCode == Activity.RESULT_OK) {
        		moveToPoint(data);
        	}
        }
    }
    
    /**
     * Funci�n que lleva a cabo la conexi�n por Bluetooth con el dispositivo pasado como dato.
     * @param data Datos provenientes del Intent.
     */
    private void connectDevice(Intent data) {
        // Obtenemos la direcci�n MAC pasada
        String address = data.getExtras().getString(DeviceListActivity.EXTRA_DEVICE_ADDRESS);
        // Obtenemos el objeto Dispositivo Bluetooth
        BluetoothDevice device = mBluetoothAdapter.getRemoteDevice(address);
        
        // Intentamos conectarnos con el dispositivo
        mService.connect(device);        	
          
    }
    
    /**
     * Funci�n que lleva a cabo el envio del mensaje del movimiento a un punto obtenido de los datos del Intent.
     * @param data Datos provenientes del Intent.
     */
    private void moveToPoint(Intent data) {
    	// Obtenemos el punto
    	String point = data.getExtras().getString(MoveToPointActivity.EXTRA_POINT);
    	
    	// Comprobamos que tenga algo
    	if (point.length() > 0) {
            // Obtenemos la secuencia de bytes del punto
            byte[] send = point.getBytes();
                	
            // Enviamos el punto
	    	mService.write(send);
    	}
    }
	
    /**
     * onCreateOptionsMenu.
     */
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflamos el men�
        getMenuInflater().inflate(R.menu.option_menu, menu);
        return true;
    }
	
    /**
     * onOptionsItemSelected.
     */
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		Intent serverIntent = null;
		// Comprobamos la selecci�n del menu
		switch(item.getItemId()){
	        case R.id.connect:
	            // Iniciamos actividad de DeviceListActivity
	        	serverIntent = new Intent(this, DeviceListActivity.class);
	            startActivityForResult(serverIntent, REQUEST_CONNECT_DEVICE);
	            return true;
	        case R.id.moveTo:
	        	//Comprobamos si esta conectado a algun dispositivo
	        	if (mService.getState() == BluetoothService.STATE_CONNECTED){
	        		 // Iniciamos actividad de MoveToPointActivity
	        		serverIntent = new Intent(this, MoveToPointActivity.class);
		            startActivityForResult(serverIntent, REQUEST_POINT);
	        	} else {
	        		Toast.makeText(this, R.string.not_connected, Toast.LENGTH_SHORT).show();
	        	}
	            return true;
	        case R.id.about:
	        	// Mostramos dialogo con la informaci�n de la aplicaci�n
	        	AlertDialog.Builder builder = new Builder(this);
	    		builder.setTitle(R.string.about);
	    		builder.setIcon(android.R.drawable.ic_menu_info_details);
	    		builder.setMessage(getString(R.string.author) + ":" +'\n'+
	    				"Jonatan Santos Barrios" +'\n'+'\n'+
	    				getString(R.string.tutor) + ":" +'\n'+
	    				"Alejandro Merino G�mez" +'\n'+ '\n' +
	    				getString(R.string.license) + ":" +'\n'+
	    				"Apache License, Version 2.0");
	    		builder.create();
	    		builder.show();
	        default:
	        	return super.onOptionsItemSelected(item);
	    }
	}
}
