package com.ubu.ububot.controlador;

import java.util.Set;

import com.ubu.ububot.R;

import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.AdapterView.OnItemClickListener;

/**
 * Actividad que muestra los dispositivos emparejados y los disponibles para conectarse a traves de Bluetooth.
 * @author     Jonatan Santos Barrios
 * @version   1.0
 */
public class DeviceListActivity extends Activity {
	// Debugging
    private static final String TAG = "DeviceListActivity";
    private static final boolean D = true;
    
    // Retorno extra del Intent
    public static String EXTRA_DEVICE_ADDRESS = "device_address";
    
    /**
     * Adaptador Bluetooth.
     */
    private BluetoothAdapter mBtAdapter;
    /**
     * Array para dispositivos emparejados.
     */
    private ArrayAdapter<String> mPairedDevicesArrayAdapter;
    /**
     * Array para nuevos dispositivos.
     */
    private ArrayAdapter<String> mNewDevicesArrayAdapter;
    
    /**
     * onCreate.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Establecemos la ventana y el layout
        requestWindowFeature(Window.FEATURE_INDETERMINATE_PROGRESS);
        setContentView(R.layout.device_list);

        // Ponemos el resultado CANCELED en caso de que el usuario vuelva hacia atras
        setResult(Activity.RESULT_CANCELED);

        // Inicializamos el boton qe permite descubrir nuevos dispositivos
        Button scanButton = (Button) findViewById(R.id.button_scan);
        scanButton.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                doDiscovery();
                v.setVisibility(View.GONE);
            }
        });

        // Inicializamos los arrays de los dispositivos
        mPairedDevicesArrayAdapter = new ArrayAdapter<String>(this, R.layout.device_name);
        mNewDevicesArrayAdapter = new ArrayAdapter<String>(this, R.layout.device_name);

        // Buscamos y establecemos el listener para los item del ListView para los dispositivos emparejados
        ListView pairedListView = (ListView) findViewById(R.id.paired_devices);
        pairedListView.setAdapter(mPairedDevicesArrayAdapter);
        pairedListView.setOnItemClickListener(mDeviceClickListener);

        // Buscamos y establecemos el listener para los item del ListView para los nuevos dispositivos
        ListView newDevicesListView = (ListView) findViewById(R.id.new_devices);
        newDevicesListView.setAdapter(mNewDevicesArrayAdapter);
        newDevicesListView.setOnItemClickListener(mDeviceClickListener);

        // Registramos el broadcasts para cuando un dispositivo nuevo es encontrado
        IntentFilter filter = new IntentFilter(BluetoothDevice.ACTION_FOUND);
        this.registerReceiver(mReceiver, filter);

        // Registramos el broadcasts para cuando se ha finalizado la busqueda
        filter = new IntentFilter(BluetoothAdapter.ACTION_DISCOVERY_FINISHED);
        this.registerReceiver(mReceiver, filter);

        // Obtenemos el adaptador Bluetooth
        mBtAdapter = BluetoothAdapter.getDefaultAdapter();

        // Obtenemos los dispositivos emparejados con anterioridad
        Set<BluetoothDevice> pairedDevices = mBtAdapter.getBondedDevices();

        // Si hay dispositivos emparejados se a�aden al array
        if (pairedDevices.size() > 0) {
            findViewById(R.id.title_paired_devices).setVisibility(View.VISIBLE);
            for (BluetoothDevice device : pairedDevices) {
                mPairedDevicesArrayAdapter.add(device.getName() + "\n" + device.getAddress());
            }
        } else {
            String noDevices = getResources().getText(R.string.not_paired).toString();
            mPairedDevicesArrayAdapter.add(noDevices);
        }
    }
    
    /**
     * onDestroy.
     */
    @Override
    protected void onDestroy() {
        super.onDestroy();

        // Nos aseguramos de no seguir con la busqueda
        if (mBtAdapter != null) {
            mBtAdapter.cancelDiscovery();
        }

        // Desregistramos el broadcast listeners
        this.unregisterReceiver(mReceiver);
    }
    
    /**
     * Empieza el descubrimiento de dispositivos con el adaptador Bluetooth.
     */
    private void doDiscovery() {
        if (D) Log.d(TAG, "doDiscovery()");

        // Cambiamos el titulo a escaneando
        setProgressBarIndeterminateVisibility(true);
        setTitle(R.string.scanning);

        // Ponemos a visible el sub-titulo de nuevos dispositivos
        findViewById(R.id.title_new_devices).setVisibility(View.VISIBLE);

        // Si estaba buscando, cancelamos la busqueda anterior
        if (mBtAdapter.isDiscovering()) {
            mBtAdapter.cancelDiscovery();
        }

        // Buscamos
        mBtAdapter.startDiscovery();
    }

    /**
     *  onClickListener para controlar cuando se pinche en uno de los items de los dispositivos
     */
    private OnItemClickListener mDeviceClickListener = new OnItemClickListener() {
        public void onItemClick(AdapterView<?> av, View v, int arg2, long arg3) {
            // Cancelamos el descubrimiento
            mBtAdapter.cancelDiscovery();

            // Obtenemos la direcci�n MAC del dispositivo
            String info = ((TextView) v).getText().toString();
            String address = info.substring(info.length() - 17);

            // Creamos el Intent resultante y a�adimos la direcci�n MAC
            Intent intent = new Intent();
            intent.putExtra(EXTRA_DEVICE_ADDRESS, address);

            // Ponemos el resultado a OK y finalizamos
            setResult(Activity.RESULT_OK, intent);
            finish();
        }
    };

    /**
     * BroadcastReceiver que escucha para recibir los dispositivos descubiertos y cambia el titulo cuando la busqueda ha finalizado.
     */
    private final BroadcastReceiver mReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            // Obtenemos la acci�n
        	String action = intent.getAction();

            // Cuando se descubreun dispositivo
            if (BluetoothDevice.ACTION_FOUND.equals(action)) {
                // Obtenemos el objeto BluetoothDevice del Intent
                BluetoothDevice device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
                // Comprobamos si es uno de los dispositivos emparejados para pasar de ellos
                if (device.getBondState() != BluetoothDevice.BOND_BONDED) {
                    mNewDevicesArrayAdapter.add(device.getName() + "\n" + device.getAddress());
                }
                
            // Cuando la busqueda finaliza cambiamos el titulo
            } else if (BluetoothAdapter.ACTION_DISCOVERY_FINISHED.equals(action)) {
                setProgressBarIndeterminateVisibility(false);
                setTitle(R.string.selection);
                // Comprobamos si habia nuevos dispositivos
                if (mNewDevicesArrayAdapter.getCount() == 0) {
                    String noDevices = getResources().getText(R.string.not_discovered).toString();
                    mNewDevicesArrayAdapter.add(noDevices);
                }
            }
        }
    };


}
