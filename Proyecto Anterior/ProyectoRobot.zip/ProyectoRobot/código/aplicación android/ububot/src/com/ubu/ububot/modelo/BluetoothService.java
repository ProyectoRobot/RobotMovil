package com.ubu.ububot.modelo;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.UUID;

import com.ubu.ububot.R;
import com.ubu.ububot.controlador.MainActivity;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;

/**
 * Servicio que se encargar del control de la conexi�n Bluetooth.
 * @author     Jonatan Santos Barrios
 * @version   1.0
 */
public class BluetoothService {

	// Debugging
    private static final String TAG = "UbuBot";
    private static final boolean D = true;

    // Identificador unico UUID para esta aplicaci�n
    private static final UUID MY_UUID = UUID.fromString("00001101-0000-1000-8000-00805f9b34fb");

    // Constantes que indican el estado de la conexi�n
    public static final int STATE_NONE = 0;       // No hace nada
    public static final int STATE_CONNECTING = 1; // Inicializando conexi�n saliente
    public static final int STATE_CONNECTED = 2;  // Conectado con un dispositivo remoto
    
    /**
     * Thread de aceptar.
     */
    //private AcceptThread mAcceptThread;
    /**
     * Thread de conectar.
     */
    private ConnectThread mConnectThread;
    /**
     * Thread de conectado.
     */
    private ConnectedThread mConnectedThread;
    
    /**
     * Adaptador Bluetooth
     */
    private final BluetoothAdapter mAdapter;
    /**
     *  Manejador
     */
    private final Handler mHandler;
    /**
     * Estado
     */
    private int mState;
    
    /**
     * Constructor. Prepara una nueva sesi�n Bluetooth.
     * @param context  Contexto de la actividad de la interfaz de usuario.
     * @param handler  Handler para enviar mensajes a la actividad de la interfaz de usuario.
     */
    public BluetoothService(Context context, Handler handler) {
        mAdapter = BluetoothAdapter.getDefaultAdapter();
        mState = STATE_NONE;
        mHandler = handler;
    }

    /**
     * Establece el estado de la conexi�n.
     * @param state  Integer que define el estado de la conexi�n.
     */
    private synchronized void setState(int state) {
        if (D) Log.d(TAG, "setState() " + mState + " -> " + state);
        mState = state;

        // Pasamos el nuevo estado al manejador para que lo actualice en la pantalla
        mHandler.obtainMessage(MainActivity.MESSAGE_STATE_CHANGE, state, -1).sendToTarget();
    }
    
    /**
     * Devuelve el estado de la conexi�n.
     * @return Integer que define el estado de la conexi�n.
     */
    public synchronized int getState() {
        return mState;
    }
    
    /**
     * Reinicia el servicio. Cancela todos los hilos de conexi�n.
     */
    public synchronized void restart() {
        
    	// Cancela cualquier Threads que estuviera intentado conectar
        if (mConnectThread != null) {mConnectThread.cancel(); mConnectThread = null;}

        // Cancela cualquier Threads que estuviera conectado
        if (mConnectedThread != null) {mConnectedThread.cancel(); mConnectedThread = null;}

        // Cambiamos el estado
        setState(STATE_NONE);
    }
    
    /**
     * Inicia el ConnectThread para inicializar una conexi�n con el dispositivo remoto.
     * @param device  El BluetoothDevice al que conectarse.
     */
    public synchronized void connect(BluetoothDevice device) {
        if (D) Log.d(TAG, "connect to: " + device);

        // Cancela cualquier Threads que estuviera intentado conectar
        if (mState == STATE_CONNECTING) {
            if (mConnectThread != null) {mConnectThread.cancel(); mConnectThread = null;}
        }

        // Cancela cualquier Threads que estuviera conectado
        if (mConnectedThread != null) {mConnectedThread.cancel(); mConnectedThread = null;}


        
        // Inicia el Thread para conectar con el dispositvo
        mConnectThread = new ConnectThread(device);
        mConnectThread.start();
        setState(STATE_CONNECTING);
    }
    
    /**
     * Inicia el ConnecterThread para manejar la conexi�n Bluettoth.
     * @param socket  El BluetoothSocket en el cual se ha realizado la coenxi�n.
     * @param device  El BluetoothDevice con el que se ha conectado.
     */
    public synchronized void connected(BluetoothSocket socket, BluetoothDevice device) {
        if (D) Log.d(TAG, "connected");

        // Cancela cualquier Threads que estuviera intentado conectar
        if (mConnectThread != null) {mConnectThread.cancel(); mConnectThread = null;}

        // Cancela cualquier Threads que estuviera conectado
        if (mConnectedThread != null) {mConnectedThread.cancel(); mConnectedThread = null;}

        // Iniciamos thread para manejar la conexi�n
        mConnectedThread = new ConnectedThread(socket);
        mConnectedThread.start();

        // Enviamos el nombre del dispositovo con el que nos hemos conectado para mostrarlo en pantalla
        Message msg = mHandler.obtainMessage(MainActivity.MESSAGE_DEVICE_NAME);
        Bundle bundle = new Bundle();
        bundle.putString(MainActivity.DEVICE_NAME, device.getName());
        msg.setData(bundle);
        mHandler.sendMessage(msg);

        // Cambiamos el estado
        setState(STATE_CONNECTED);
    }
    
    /**
     * Para todos los threads
     */
    public synchronized void stop() {
        if (D) Log.d(TAG, "stop");

        if (mConnectThread != null) {
            mConnectThread.cancel();
            mConnectThread = null;
        }

        if (mConnectedThread != null) {
            mConnectedThread.cancel();
            mConnectedThread = null;
        }
        
        // Cambiamos el estado
        setState(STATE_NONE);
    }
    
    /**
     * Indica que la conexi�n ha fallado y se lo comunica a la actividad de la interfaz de usuario.
     */
    private void connectionFailed() {
        // Enviamos mensaje de que no se ha podido conectar
        Message msg = mHandler.obtainMessage(MainActivity.MESSAGE_TOAST);
        Bundle bundle = new Bundle();
        bundle.putLong(MainActivity.TOAST, R.string.imposible_to_connect);
        msg.setData(bundle);
        mHandler.sendMessage(msg);
        
        // Reiniciamos
        restart();
    }

    /**
     * Indica que la conexi�n se ha perdido y se lo comunica a la actividad de la interfaz de usuario.
     */
    private void connectionLost() {
    	// Enviamos mensaje de que se ha perdido la conexion
        Message msg = mHandler.obtainMessage(MainActivity.MESSAGE_TOAST);
        Bundle bundle = new Bundle();
        bundle.putLong(MainActivity.TOAST, R.string.lost_connection);
        msg.setData(bundle);
        mHandler.sendMessage(msg);
        
        // Reiniciamos
        restart();
    }

    /**
     * Manda por conexi�n bluetooth la cadena de bytes.
     * @param out Cadena de bytes a enviar.
     */
    public void write(byte[] out) {
        // Creamos un objeto temporal
        ConnectedThread r;
        // Sincronizamos con el ConnectedThread
        synchronized (this) {
            if (mState != STATE_CONNECTED) return;
            r = mConnectedThread;
        }
        // Escribimos desde el objeto temporal
        r.write(out);
    }
    
    /**
     * Este hilo se ejecuta al intentar realizar una conexi�n de salida con un dispositivo. 
     * Se ejecuta directamente, la conexi�n puede ser exitosa o fracasar.
     * @see Thread
     */
    private class ConnectThread extends Thread {
        /**
         * Socket Bluetooth.
         */
    	private final BluetoothSocket mmSocket;
    	
    	/**
    	 * Dispositivo Bluetooth.
    	 */
        private final BluetoothDevice mmDevice;

        /**
         * Constructor. Inicializa el socket.
         * @param device Dispositivo con el que se realiza la conexi�n Bluetooth
         */
        public ConnectThread(BluetoothDevice device) {
            mmDevice = device;            
            BluetoothSocket tmp = null;

            // Obtenemos el BluetoothSocket para una conexion con el BluetoothDevice pasado
            try {
            	tmp = mmDevice.createRfcommSocketToServiceRecord(MY_UUID);
            } catch (IOException e) {
                Log.e(TAG, "Fallo en la creaci�n del socket Bluetooth.", e);
            }
            mmSocket = tmp;
        }

        /**
         * run.
         */
        @Override
        public void run() {
            setName("ConnectThread");

            // Cancelamos el descubrimiento para una mayor rapidez en la conexi�n
            mAdapter.cancelDiscovery();

            // Hacemos una conexi�n al BluetoothSocket
            try {
            	// Esta es una llamada de bloqueo y s�lo regresar� en una conexi�n correcta o una excepci�n
            	mmSocket.connect();
            } catch (IOException e) {
            	Log.i(TAG, "Fallo en mConnectThread en la conexi�n Bluetooth.", e);
                // Cerramos el socket
                try {
                    mmSocket.close();
                } catch (IOException e2) {
                    Log.e(TAG, "Fallo durante la conexi�n, imposible cerrar el socket", e2);
                }
                connectionFailed();
                return;
            }

            // Reseteamos el ConnectThread
            synchronized (BluetoothService.this) {
                mConnectThread = null;
            }

            // Comenzamos el thread de conexi�n
            connected(mmSocket, mmDevice);
        }

        /**
         * Cierra el socket.
         */
        public void cancel() {
            try {
                mmSocket.close();
            } catch (IOException e) {
                Log.e(TAG, "Fallo al cerrar el socket", e);
            }
        }
    }

    /**
     * Este hilo se ejecuta durante una conexi�n con un dispositivo remoto. 
     * Maneja todas las transmisiones entrantes y salientes.
     * @see Thread
     */
    private class ConnectedThread extends Thread {
        /**
         * Socket del bluetooth.
         */
    	private final BluetoothSocket mmSocket;
    	/**
    	 * Stream de entrada.
    	 */
        private final InputStream mmInStream;
        /**
         * Stream de salida.
         */
        private final OutputStream mmOutStream;

        /**
         * Constructor. Obtiene del socket los streams de entrada y salida.
         * @param socket Socket del bluetooth
         */
        public ConnectedThread(BluetoothSocket socket) {
            mmSocket = socket;
            InputStream tmpIn = null;
            OutputStream tmpOut = null;

            // Obtenemos los streams de entrada y salida del BluetoothSocket
            try {
                tmpIn = socket.getInputStream();
                tmpOut = socket.getOutputStream();
            } catch (IOException e) {
                Log.e(TAG, "Error al crear los stream del socket.", e);
            }

            mmInStream = tmpIn;
            mmOutStream = tmpOut;
        }

        /**
         * run.
         */
        @Override
        public void run() {
            byte[] buffer = new byte[1024];
            int bytes;

            // Nos mantememos escuchando InputStream mientras este conectado
            while (true) {
                try {
                    // Leemos el InputStream
                    bytes = mmInStream.read(buffer);

                    // Enviamos los bytes recogidos al Handler del MainActivity
                    mHandler.obtainMessage(MainActivity.MESSAGE_READ, bytes, -1, buffer).sendToTarget();
                } catch (IOException e) {
                    Log.e(TAG, "Desconectada la conexi�n Bluetooth", e);
                    connectionLost();
                    // Iniciamos el servicio para restaurar los thread
                    BluetoothService.this.restart();
                    break;
                }
            }
        }

        /**
         * Escribe en el stream de salida.
         * @param buffer  Cadena de bytes a enviar
         */
        public void write(byte[] buffer) {
            try {
                mmOutStream.write(buffer);
            } catch (IOException e) {
                Log.e(TAG, "Excepci�n al enviar.", e);
            }
        }

        /**
         * Cierra el socket.
         */
        public void cancel() {
            try {
                mmSocket.close();
            } catch (IOException e) {
                Log.e(TAG, "Fallo al cerrar el socket de conexi�n.", e);
            }
        }
    }
}