var _comunicacion_8c =
[
    [ "deshabilitarTimeOut", "_comunicacion_8c.html#a35bbeed3edc5ac4f1131ec04f6b51046", null ],
    [ "enviarPosicion", "_comunicacion_8c.html#ae24a1218529e5a0fa9b6ecd3699e3729", null ],
    [ "establecerAceleracion", "_comunicacion_8c.html#ac557c4c70c750a11265edf3ce6878e79", null ],
    [ "establecerModo", "_comunicacion_8c.html#a3f386ce84ff42cd57c3e214d7ca49b16", null ],
    [ "establecerVelocidad1", "_comunicacion_8c.html#adc82dc3975fe3eabf8e6e529450a2b6f", null ],
    [ "establecerVelocidad2", "_comunicacion_8c.html#a79b0d45251317650ee05e2b23ee4d80a", null ],
    [ "habilitarTimeOut", "_comunicacion_8c.html#a3aa0de2f2c5c1fe290cad805aa8f76ff", null ],
    [ "obtenerEncoder1", "_comunicacion_8c.html#a896a21d8e53296e1b5861bbf55815e41", null ],
    [ "obtenerEncoder2", "_comunicacion_8c.html#a4dbf72a667baa77a7878e5261facf709", null ],
    [ "obtenerModo", "_comunicacion_8c.html#aa93d76ff61bd63b488a5ef387f91df24", null ],
    [ "obtenerVelocidad1", "_comunicacion_8c.html#a732078afc3f48a2bee2682fa00c2b7fc", null ],
    [ "obtenerVelocidad2", "_comunicacion_8c.html#af0c64adebe8553f9a53e4a4e7a0307e0", null ],
    [ "resetearEncoders", "_comunicacion_8c.html#aaf32737958ee838d6838a3449ba90a65", null ]
];