var dir_9c61b76ac29cec217ebdb7cae0d43cea =
[
    [ "Comunicacion.c", "_comunicacion_8c.html", "_comunicacion_8c" ]
];