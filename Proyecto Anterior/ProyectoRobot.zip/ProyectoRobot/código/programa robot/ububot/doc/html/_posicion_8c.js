var _posicion_8c =
[
    [ "obtenerAng", "_posicion_8c.html#a57428ebe7e4154bd24d8d845c4caa564", null ],
    [ "obtenerX", "_posicion_8c.html#a60884b1f6f6df336faaf507e5f10205e", null ],
    [ "obtenerY", "_posicion_8c.html#a16adec438ef6b602b605b5d68d22165b", null ],
    [ "posicionar", "_posicion_8c.html#ab53648a5d1c51ea2f1773df4d341a90d", null ],
    [ "ang", "_posicion_8c.html#aa28cf03c8598a97a6144a86d8aafc9f6", null ],
    [ "encoder1Ant", "_posicion_8c.html#ac79fa055a79d414127813bba08fdcd80", null ],
    [ "encoder2Ant", "_posicion_8c.html#ab1bfaeae3eb34ae41f0f792ab3580b0e", null ],
    [ "x", "_posicion_8c.html#af88b946fb90d5f08b5fb740c70e98c10", null ],
    [ "y", "_posicion_8c.html#ab927965981178aa1fba979a37168db2a", null ]
];