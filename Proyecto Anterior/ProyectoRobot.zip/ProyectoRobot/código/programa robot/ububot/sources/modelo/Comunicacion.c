/**
 * Clase que controla la comunicacion tanto con los motores como con el modulo bluetooth.
 * @file modelo/Comunicacion.c
 * @author Jonatan Santos Barrios
 * @date 17/11/2013
 * @version 1.0
 */

#include "AS1.h"
#include "AS2.h"
#include "modelo/Comunicacion.h"
#include "stdlib.h"

/**
 * @brief Envio de la velocidad a los motores
 * 
 * Envia el valor de velocidad a la controladora de motores, segun el modo de trabajo
 * correspondera a velocidad de un motor o de ambos.
 * @param velocidad Segun el modo de trabajo el valor de velocidad ira entre 0 y 255 o -128 y 127.
 */
void establecerVelocidad1(byte velocidad){
	// Mandamos los bytes del mensaje
	while(AS1_SendChar(0x00) != ERR_OK) {};
	while(AS1_SendChar(0x31) != ERR_OK) {};
	while(AS1_SendChar(velocidad) != ERR_OK) {};
}

/**
 * @brief Envio de la velocidad a los motores
 * 
 * Envia el valor de velocidad a la controladora de motores, segun el modo de trabajo
 * correspondera a velocidad de un motor o la velocidad angular.
 * @param velocidad Segun el modo de trabajo el valor de velocidad ira entre 0 y 255 o -128 y 127.
 */
void establecerVelocidad2(byte velocidad){
	// Mandamos los bytes del mensaje
	while(AS1_SendChar(0x00) != ERR_OK) {};
	while(AS1_SendChar(0x32) != ERR_OK) {};
	while(AS1_SendChar(velocidad) != ERR_OK) {};
}

/**
 * @brief Envio de la aceleracion a los motores
 * 
 * Envia el valor de aceleracion de los motores a la controladora de motores.
 * @param aceleracion Un valor de aceleracion entre 1 y 10.
 */
void establecerAceleracion(byte aceleracion){
	// Mandamos los bytes del mensaje
	while(AS1_SendChar(0x00) != ERR_OK) {};
	while(AS1_SendChar(0x33) != ERR_OK) {};
	while(AS1_SendChar(aceleracion) != ERR_OK) {};
}

/**
 * @brief Envio de del modo de trabajo a los motores.
 * 
 * Envia el valor del modo de trabajo de los motores a la controladora de motores.\n
 * Modos de trabajo: \n
 * &nbsp;&nbsp;0 - establecerVelocidad1 para motor1 y establecerVelocidad2 para motor2; valores entre 0 y 255.\n
 * &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;0 - Maxima velocidad hacia atras\n
 * &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;128 - Parado\n
 * &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;255 - Maxima velocidad hacia adelante.\n
 * &nbsp;&nbsp;1 - establecerVelocidad1 para motor1 y establecerVelocidad2 para motor2.\n
 * &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;-128 - Maxima velocidad hacia atras\n
 * &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;0 - Parado\n
 * &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;127 - Maxima velocidad hacia adelante.\n
 * &nbsp;&nbsp;2 - establecerVelocidad1 controla la velocidad de los dos motores y establecerVelocidad2 controla la velocidad angula o de giro.\n
 * &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;0 - Maxima velocidad hacia atras\n
 * &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;128 - Parado\n
 * &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;255 - Maxima velocidad hacia adelante.\n
 * &nbsp;&nbsp;3 - establecerVelocidad1 controla la velocidad de los dos motores y establecerVelocidad2 controla la velocidad angula o de giro.\n
 * &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;-128 - Maxima velocidad hacia atras\n
 * &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;0 - Parado\n
 * &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;127 - Maxima velocidad hacia adelante.\n
 * @param modo Un valor 0 y 3.
 */
void establecerModo(byte modo){
	// Mandamos los bytes del mensaje
	while(AS1_SendChar(0x00) != ERR_OK) {};
	while(AS1_SendChar(0x34) != ERR_OK) {};
	while(AS1_SendChar(modo) != ERR_OK) {};
}

/**
 * @brief Obtener el modo de trabajo de los motores
 * 
 * Pregunta a la controla de motores el modo de trabajo de los mismos.
 * Modos de trabajo: \n
 * &nbsp;&nbsp;0 - establecerVelocidad1 para motor1 y establecerVelocidad2 para motor2; valores entre 0 y 255.\n
 * &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;0 - Maxima velocidad hacia atras\n
 * &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;128 - Parado\n
 * &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;255 - Maxima velocidad hacia adelante.\n
 * &nbsp;&nbsp;1 - establecerVelocidad1 para motor1 y establecerVelocidad2 para motor2.\n
 * &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;-128 - Maxima velocidad hacia atras\n
 * &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;0 - Parado\n
 * &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;127 - Maxima velocidad hacia adelante.\n
 * &nbsp;&nbsp;2 - establecerVelocidad1 controla la velocidad de los dos motores y establecerVelocidad2 controla la velocidad angula o de giro.\n
 * &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;0 - Maxima velocidad hacia atras\n
 * &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;128 - Parado\n
 * &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;255 - Maxima velocidad hacia adelante.\n
 * &nbsp;&nbsp;3 - establecerVelocidad1 controla la velocidad de los dos motores y establecerVelocidad2 controla la velocidad angula o de giro.\n
 * &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;-128 - Maxima velocidad hacia atras\n
 * &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;0 - Parado\n
 * &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;127 - Maxima velocidad hacia adelante.\n
 * @return El modo de trabajo, un valor entre 0 y 3.
 */
byte obtenerModo(){
	// Variable del dato a recibir
	AS1_TComData dato;
	
	// Mandamos los bytes del mensaje
	while(AS1_SendChar(0x00) != ERR_OK) {};
	while(AS1_SendChar(0x2B) != ERR_OK) {};
	// Recibimos el dato
	while(AS1_RecvChar(&dato) != ERR_OK) {};
	
	// Devolvemos el dato
	return dato;
}

/**
 * @brief Obtener la velocidad de los motores
 * 
 * Pregunta a la controladora la velocidad de los motores, segun el modo de trabajo
 * correspondera a velocidad de un motor o de ambos.
 * @return Segun el modo de trabajo el valor de la velocidad ira entre 0 y 255 o -128 y 127.
 */
byte obtenerVelocidad1(){
	// Variable del dato a recibir
	AS1_TComData dato;
	
	// Mandamos los bytes del mensaje
	while(AS1_SendChar(0x00) != ERR_OK) {};
	while(AS1_SendChar(0x21) != ERR_OK) {};
	// Recibimos el dato
	while(AS1_RecvChar(&dato) != ERR_OK) {};
	
	// Devolvemos el dato
	return dato;
}

/**
 * @brief Obtener la velocidad de los motores
 * 
 * Pregunta a la controladora la velocidad de los motores, segun el modo de trabajo
 * correspondera a velocidad de un motor o la velocidad angular.
 * @return Segun el modo de trabajo el valor de la velocidad ira entre 0 y 255 o -128 y 127.
 */
byte obtenerVelocidad2(){
	// Variable del dato a recibir
	AS1_TComData dato;
	
	// Mandamos los bytes del mensaje
	while(AS1_SendChar(0x00) != ERR_OK) {};
	while(AS1_SendChar(0x22) != ERR_OK) {};
	// Recibimos el dato
	while(AS1_RecvChar(&dato) != ERR_OK) {};
	
	// Devolvemos el dato
	return dato;
}

/**
 * @brief Obtener el valor del encoder del motor1
 * 
 * Pregunta a la controladora el valor del encoder1.
 * @return Valor del encoder1 devuelto por la controladora.
 */
long obtenerEncoder1(){
	// Contador
	int i;
	// Variable del resultado
	long result;
	// Variable del dato a recibir
	AS1_TComData dato;
	
	// Mandamos los bytes del mensaje
	while(AS1_SendChar(0x00) != ERR_OK) {};
	while(AS1_SendChar(0x23) != ERR_OK) {};
	// Bucle para recibir los 4 bytes de la respuesta
	for(i = 0; i < 4; i++){
		// Recibimos el dato
		while(AS1_RecvChar(&dato) != ERR_OK) {};
		// Segun el n� de dato tiene un valor u otro.
		switch (i){
			case 0:
				result = dato << 24;
				break;
			case 1:
				result += dato << 16;
				break;
			case 2:
				result += dato << 8;
				break;
			case 3:
				result += dato;
		}
	}
	// Devolvemos el resultado
	return result;
}

/**
 * @brief Obtener el valor del encoder del motor2
 * 
 * Pregunta a la controladora el valor del encoder2.
 * @return Valor del encoder2 devuelto por la controladora.
 */
long obtenerEncoder2(){
	// Contador
	int i;
	// Variable del resultado
	long result;
	// Variable del dato a recibir
	AS1_TComData dato;
	
	// Mandamos los bytes del mensaje
	while(AS1_SendChar(0x00) != ERR_OK) {};
	while(AS1_SendChar(0x24) != ERR_OK) {};
	// Bucle para recibir los 4 bytes de la respuesta
	for(i = 0; i < 4; i++){
		// Recibimos el dato
		while(AS1_RecvChar(&dato) != ERR_OK) {};
		// Segun el n� de dato tiene un valor u otro.
		switch (i){
			case 0:
				result = dato << 24;
				break;
			case 1:
				result += dato << 16;
				break;
			case 2:
				result += dato << 8;
				break;
			case 3:
				result += dato;
		}
	}
	// Devolvemos el resultado
	return result;
}

/**
 * @brief Resetea los encoder
 * 
 * Manda a la controladora la orden de poner a 0 los encodres.
 */
void resetearEncoders(){
	// Mandamos los bytes del mensaje
	while(AS1_SendChar(0x00) != ERR_OK) {};
	while(AS1_SendChar(0x35) != ERR_OK) {};	
}

/**
 * @brief Deshabilita el timeout.
 * 
 * Manda a la controladora la orden de deshabilitar el timeout.
 * Si el timeout esta habilitado el movimiento finaliza a los dos segundos si no se recibe ninguno orden nueva de movimiento, 
 * estando habilitado el moviento se mantiene hasta recibir una nueva orden.
 */
void deshabilitarTimeOut(){
	// Mandamos los bytes del mensaje
	while(AS1_SendChar(0x00) != ERR_OK) {};
	while(AS1_SendChar(0x38) != ERR_OK) {};	
}

/**
 * @brief Deshabilita el timeout.
 * 
 * Manda a la controladora la orden de deshabilitar el timeout.
 * Si el timeout esta habilitado el movimiento finaliza a los dos segundos si no se recibe ninguno orden nueva de movimiento, 
 * estando habilitado el moviento se mantiene hasta recibir una nueva orden.
 */
void habilitarTimeOut(){
	// Mandamos los bytes del mensaje
	while(AS1_SendChar(0x00) != ERR_OK) {};
	while(AS1_SendChar(0x39) != ERR_OK) {};	
}

/**
 * @brief Envia las coordenadas.
 * 
 * Envia las coordenadas de la posicion al modulo bluetooth.
 * @param x Valor de la coordenada X
 * @param y Valor de la coordenada Y
 */
void enviarPosicion(int x, int y){
	// Enviamos una X
	while(AS2_SendChar('X') != ERR_OK) {};
	// Comprobamos si el valor es positivo o negativo
	if (x < 0){
		// Enviamos el signo negativo
		while(AS2_SendChar('-') != ERR_OK) {};
	} else {
		// Enviamos un 0
		while(AS2_SendChar('0') != ERR_OK) {};
	}
	// Enviamos digito a digito el numero
	while(AS2_SendChar((char)(48+((int)abs(x)/10000)))!= ERR_OK) {};
	while(AS2_SendChar((char)(48+((int)abs(x)%10000)/1000))!= ERR_OK) {};
	while(AS2_SendChar((char)(48+((int)abs(x)%1000)/100))!= ERR_OK) {};
	while(AS2_SendChar((char)(48+((int)abs(x)%100)/10))!= ERR_OK) {};
	while(AS2_SendChar((char)(48+((int)abs(x)%10)))!= ERR_OK) {};
	// Enviamos una Y
	while(AS2_SendChar('Y') != ERR_OK) {};
	// Comprobamos si el valor es positivo o negativo
	if (y < 0){
		// Enviamos el signo negativo
		while(AS2_SendChar('-') != ERR_OK) {};
	} else {
		// Enviamos un 0
		while(AS2_SendChar('0') != ERR_OK) {};
	}
	// Enviamos digito a digito el numero
	while(AS2_SendChar((char)(48+((int)abs(y)/10000)))!= ERR_OK) {};
	while(AS2_SendChar((char)(48+((int)abs(y)%10000)/1000))!= ERR_OK) {};
	while(AS2_SendChar((char)(48+((int)abs(y)%1000)/100))!= ERR_OK) {};
	while(AS2_SendChar((char)(48+((int)abs(y)%100)/10))!= ERR_OK) {};
	while(AS2_SendChar((char)(48+((int)abs(y)%10)))!= ERR_OK) {};	
}
