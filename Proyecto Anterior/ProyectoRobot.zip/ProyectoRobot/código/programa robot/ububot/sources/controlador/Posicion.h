void posicionar();
int obtenerAng();
int obtenerX();
int obtenerY();