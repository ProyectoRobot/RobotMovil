/**
 * Clase que controla y genera los movimientos.
 * @file controlador/Movimiento.c
 * @author Jonatan Santos Barrios
 * @date 20/11/2013
 * @version 1.0
 */

#define PI 3.1415926535897932384626 

#include "AS1.h"
#include "AS2.h"
#include "Bit1.h"
#include "controlador/Movimiento.h"
#include "modelo/Comunicacion.h"
#include "controlador/Posicion.h"
#include "Math.h"

/**
 * @brief Movimiento por velocidades.
 * 
 * Calcula las velocidades a enviar a la controladora segun el modo de trabajo, y manda las ordenes.
 * @param velocidad El valor de velocidad ira entre -128 y 127.
 * @param angulo El valor de velocidad ira entre -128 y 127.
 */
void mover(int velocidad, int angular){
	// Modo de trabajo
	byte modo;
	// Velocidades de los motores
	int velocidad1, velocidad2;
	
	// Comprobamos si esta en movimiento para indicarlo con el led correspondiente
	if(velocidad == 0 && angular == 0){
		Bit1_PutVal(0);
	} else {
		Bit1_PutVal(1);
	}
	
	// Comprobamos que la velocidad y el angulo estan dentro de los posibles valores
	if(velocidad >= -128 && velocidad < 128 && angular >= -128 && angular < 128){
	
		//  Obtenemos el modo
		modo = obtenerModo();
		// Seg�n el modo calculamos las velocidades
		switch(modo){
			case 0x00:
				velocidad1 = velocidad + angular + 128;
				velocidad2 = velocidad - angular + 128;
				if(velocidad1 > 255){
					velocidad1 = 255;
				} else if (velocidad1 < 0){
					velocidad1 = 0;
				}
				if(velocidad2 > 255){
					velocidad2 = 255;
				} else if (velocidad2 < 0){
					velocidad2 = 0;
				}				
				break;
			case 0x01:
				velocidad1 = velocidad + angular;
				velocidad2 = velocidad - angular;
				if(velocidad1 > 127){
					velocidad1 = 127;
				} else if (velocidad1 < -128){
					velocidad1 = -128;
				}
				if(velocidad2 > 127){
					velocidad2 = 127;
				} else if (velocidad2 < -128){
					velocidad2 = -128;
				}
				break;
			case 0x02:
				velocidad1 = velocidad + 128;
				velocidad2 = angular + 128;
				break;
			case 0x03:
				velocidad1 = velocidad;
				velocidad2 = angular;
				break;
		}
		
		// Mandamos las velocidades al controlador de motores
		establecerVelocidad1(velocidad1);
		establecerVelocidad2(velocidad2);
	}
}

/**
 * @brief Movimiento a un punto.
 * 
 * Implementa el algoritmo adecuado para mediante ordenes de movimiento llegar hasta el destino indicado.
 * @param xDestino Valor de la coordenada X del destino final.
 * @param yDestino Valor de la coordenada X del destino final.
 */
void moverAPosicion(int xDestino, int yDestino){
	// Valores de la posicion del robot
	int x, y, ang;
	// Valores de distancias
	int distX, distY, distDestino;
	// Valor del angulo de giro
	int angGiro;
	// Valore de la velocidad
	int velocidad;
	// Contador
	int cont = 0;
	
	// Bucle principal del algoritmo de direcci�n a un punto
	for(;;){
		// Aumentamos en uno el contador
		cont ++;
		// Obtenemos la posicion actual
		x = obtenerX();
		y = obtenerY();
		ang = obtenerAng();
		// Calculamos la distancia en x e y al destino
		distX = xDestino - x;
		distY = yDestino - y;
		
		// Comprobamos si hemos llegado a la posici�n
		if(distX >= -50 && distX <= 50 && distY >= -50 && distY <= 50){
			// Paramos y salimos del for
			mover(0,0);
			break;
		} else {
			// Calculamos la distancia al destino
			distDestino = sqrt(pow(distX,2) + pow(distY,2));
			
			// Calculamos el angulo formado por el angulo del robot y el punto destino
			angGiro = 180 + ((180/PI)*atan2(y-yDestino, x-xDestino)) - ang;
			
			// Comprobamos si el valor del angulo de giro esta entre -179 y 180
			if(angGiro > 180){
				angGiro = angGiro - 360;
			} else if(angGiro<-179){
				angGiro = angGiro + 360;
			}
			
			// Calculamos la velocidad segun la distancia de destino
			if(distDestino > 5000) {
				// Maxima velocidad
				velocidad = 127;
			} else if (distDestino > 1000){
				// Seg�n la distancia calculamos una velocidad media(valor entre 128 y 50)
				velocidad = 50 + ((distDestino-1000)*78/4000);
			} else {
				// Seg�n la distancia calculamos una velocidad lenta(valor entre 50 y 1)
				velocidad = (distDestino*50/1000) + 1;
			}
			
			// Seg�n el valor del angulo actuamos
			if(angGiro > -5 && angGiro < 5){
				// Simplemente avanzamos hacia adelante
				mover(velocidad,0);
			} else if(angGiro > -45 && angGiro < 45){
				// Avanzamos y giramos a la vez
				mover(velocidad,angGiro/2);
			} else {
				// Simplemente giramos el robot
				mover(0,angGiro/2);
			}
			// Posicionamos el robot
			posicionar();
			
			// Si a pasado cierto numero de iteraci�n enviamos la posici�n al usuario
			if (cont == 5){
				enviarPosicion(obtenerX(), obtenerY());
				// Reiniciamos contador
				cont = 0;
			}
		}	
	}
}