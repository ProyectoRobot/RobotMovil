/**
 * Clase controladora de la posicion del robot.
 * @file controlador/Posicion.c
 * @author Jonatan Santos Barrios
 * @date 02/12/2013
 * @version 1.0
 */

#define PI 3.1415926535897932384626 

#include "AS1.h"
#include "controlador/Posicion.h"
#include "modelo/Comunicacion.h"
#include "Math.h"

double x; ///< Double con la posicion X.
double y; ///< Double con la posicion Y.
double ang;  ///< Double con el angulo de orientacion.
long encoder1Ant; ///< Long con el valor del encoder1 de la anterior posicion anterior.
long encoder2Ant; ///< Long con el valor del encoder2 de la anterior posicion anterior.

/**
 * @brief Calcula la posicion del robot.
 * 
 * Calcula la posicion del robot segun los valores de los encoders del motor.
 */
void posicionar(){
	// Angulo en radiales
	double angRadiales;
	// Distancias
	float distPulso, distEncoder1, distEncoder2, distRecorrida;
	// Valores de los encoders
	long encoder1, encoder2;
	
	// Calculo de distancia recorrida por pulso
	distPulso = 2*PI*50/360;
	
	// Obtenemos los valores de los encoders
	encoder1= obtenerEncoder1();
	encoder2= obtenerEncoder2();
	
	// Obtenemos la distancia recorrida por el enconder1
	distEncoder1 = distPulso * (encoder1 - encoder1Ant);
	
	// Obtenemos la distancia recorrida por el enconder1
	distEncoder2 = distPulso * (encoder2 - encoder2Ant);
	
	// Guardamos los valores para el siguiente calculo
	encoder1Ant = encoder1;
	encoder2Ant = encoder2;
	
	// Calculamos la distancia recorrida
	distRecorrida = (distEncoder1 + distEncoder2)/2;
	
	// Calculamos el angulo del robot
	angRadiales = distPulso * (encoder1 - encoder2)/(float)300;
	
	// Pasamos de radiales a grados
	ang = angRadiales * 180 / PI;
	
	// Obtenemos el angulo en un valor menor de 360
	ang = (int)ang%360;
	// Pasamos el angulo a un valor comprendido entre -179 y 180
	if(ang > 180){
		ang = ang - 360;
	} else if(ang<-179){
		ang = ang + 360;
	}
	
	// Calculamos ahora la 'x' y la 'y'
	x += distRecorrida * cos(angRadiales);
	y += distRecorrida * sin(angRadiales);
}

/**
 * @brief Obtiene la coordenada X del robot.
 * 
 * Retorna el valor de la coordenada X de la posicion del robot.
 * @return Integer con el valor en mm de la coordenada X.
 */
int obtenerX(){
	return (int)x;
}

/**
 * @brief Obtiene la coordenada Y del robot.
 * 
 * Retorna el valor de la coordenada Y de la posicion del robot.
 * @return Integer con el valor en mm de la coordenada Y.
 */
int obtenerY(){
	return (int)y;
}

/**
 * @brief Obtiene el angulo de orientacion del robot.
 * 
 * Retorna el valor del angulo de orientacion en que se encuentra el robot.
 * @return Integer con el valor del angulo de orientacion del robot.
 */
int obtenerAng(){
	return (int)ang;
}