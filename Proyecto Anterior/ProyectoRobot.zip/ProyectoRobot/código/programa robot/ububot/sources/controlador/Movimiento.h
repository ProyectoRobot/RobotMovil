void mover(int velocidad, int angulo);
void moverAPosicion(int xDestino, int yDestino);