/**
 * Programa principal. Inicio del programa.
 * @file controlador/ProcessorExpert.c
 * @author Jonatan Santos Barrios
 * @date 17/11/2013
 * @version 1.0
 */

/* Including needed modules to compile this module/procedure */
#include "Cpu.h"
#include "Events.h"
#include "AS1.h"
#include "AS2.h"
#include "Bit1.h"

/* Including shared modules, which are used for whole project */
#include "PE_Types.h"
#include "PE_Error.h"
#include "PE_Const.h"
#include "IO_Map.h"

/* User includes (#include below this line is not maintained by Processor Expert) */
#include "modelo/Comunicacion.h"
#include "controlador/Movimiento.h"
#include "controlador/Posicion.h"

/**
 * Tarea principal. Se ejecuta continuamente recogiendo los datos recibidos
 * por bluetooth para despues actuar segun el mensaje recibido.
 * 
 */
void main(void)
{
	AS2_TComData dato; // Dato recibido por el puerto serie perteneciente al modulo bluetooth.
	bool negativo; // Boolean para guardar el signo del valor recibido.
	int valor; // Valor recibido por el modulo bluetooth.
	int vel; // Velocidad del robot.
	int velAng; // Velocidad angular o de giro.
	int x; // Valor de la coordenada X
	int y; // Valor de la coordenada Y
	int cont=0; // Contador

	// Inicializamos los registros
	PE_low_level_init();
	
	// Reseteamos los encoders
	resetearEncoders();
	
	// Establecemos el modo de trabajo de los encoders
	establecerModo(0x00);
	
	// Deshabilitamos el TimeOut de los encoders
	deshabilitarTimeOut();
	
	// Bucle principal que se ejecuta continuamente
	for(;;){
		// Aumentamos el contador en una unidad
		cont ++;
		
		// Comprobamos si hemos recibido alg�n dato
		if(AS2_RecvChar(&dato) == ERR_OK){
			// Comprobamos si es una X, lo que significa que es un movimiento a un punto concreto
			if(dato == 88){
				// Vamos obteniendo el resto del mensaje y construyendo el n�mero
				while(AS2_RecvChar(&dato) != ERR_OK){};
				if(dato == 48){
					negativo = FALSE;
				} else {
					negativo = TRUE;
				}
				while(AS2_RecvChar(&dato) != ERR_OK){};
				valor = (dato-48)*10000;
				while(AS2_RecvChar(&dato) != ERR_OK){};
				valor += (dato-48)*1000; 
				while(AS2_RecvChar(&dato) != ERR_OK){};
				valor += (dato-48)*100; 
				while(AS2_RecvChar(&dato) != ERR_OK){};
				valor += (dato-48)*10; 
				while(AS2_RecvChar(&dato) != ERR_OK){};
				valor += (dato-48); 
				while(AS2_RecvChar(&dato) != ERR_OK){};
				x = valor;
				if(negativo == TRUE){
					x = -x;
				}						
				while(AS2_RecvChar(&dato) != ERR_OK){};
				if(dato == 48){
					negativo = FALSE;
				} else {
					negativo = TRUE;
				}
				while(AS2_RecvChar(&dato) != ERR_OK){};
				valor = (dato-48)*10000; 
				while(AS2_RecvChar(&dato) != ERR_OK){};
				valor += (dato-48)*1000; 
				while(AS2_RecvChar(&dato) != ERR_OK){};
				valor += (dato-48)*100; 
				while(AS2_RecvChar(&dato) != ERR_OK){};
				valor += (dato-48)*10; 
				while(AS2_RecvChar(&dato) != ERR_OK){};
				valor += (dato-48); 
				y = valor;
				if(negativo == TRUE){
					y = -y;
				}
				// Llamamos a la funci�n para mover al punto recibido
				moverAPosicion(x,y);
			// Comprobamos si es una M, lo que significa que es un movimiento libre
			} else if (dato == 77){
				// Vamos obteniendo el resto del mensaje y construyendo el n�mero
				while(AS2_RecvChar(&dato) != ERR_OK){};
				if(dato == 48){
					negativo = FALSE;
				} else {
					negativo = TRUE;
				}
				while(AS2_RecvChar(&dato) != ERR_OK){};
				valor = (dato-48)*100; 
				while(AS2_RecvChar(&dato) != ERR_OK){};
				valor += (dato-48)*10; 
				while(AS2_RecvChar(&dato) != ERR_OK){};
				valor += (dato-48); 
				while(AS2_RecvChar(&dato) != ERR_OK){};
				vel = valor;
				if(negativo == TRUE){
					vel = -vel;
				}						
				while(AS2_RecvChar(&dato) != ERR_OK){};
				if(dato == 48){
					negativo = FALSE;
				} else {
					negativo = TRUE;
				}
				while(AS2_RecvChar(&dato) != ERR_OK){};
				valor = (dato-48)*100; 
				while(AS2_RecvChar(&dato) != ERR_OK){};
				valor += (dato-48)*10; 
				while(AS2_RecvChar(&dato) != ERR_OK){};
				valor += (dato-48); 
				velAng = valor;
				if(negativo == TRUE){
					velAng = -velAng;
				}
				// Llamamos a la funci�n para mover pasandole las velocidades recibidas
				mover(vel,velAng);
				// Llamamos a la funci�n posicionar, para calcular la posici�n del robot
				posicionar();
			}
		}
		// Cada cierto tiempo, o numero de iteraciones realizamos las operaciones
		if (cont == 500000){
			// Llamamos a la funci�n posicionar, para calcular la posici�n del robot
			posicionar();
			// Enviamos por bluetooth las coordenadas dondese encuentra el robot, para que el usuario tenga conocimiento de su posici�n.
			enviarPosicion(obtenerX(), obtenerY());
			// Iniciamos el contador
			cont = 0;
		}
	}
} 
